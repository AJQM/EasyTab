import javax.swing.JFrame;

public class DisplayTab extends JFrame {

}
