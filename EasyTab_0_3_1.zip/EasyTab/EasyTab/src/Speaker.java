
public class Speaker {
	double speaks = 0;
	String name;
	double roundSpeaks = 0;
	public Speaker(String nameIn) {
		name = nameIn;
	}
}
